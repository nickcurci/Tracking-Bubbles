%Read files from the directory, make them binary, crop them, find centroid

for k = 1 : 5
	
    % Read through sequential images and show them.
	tifFileName = strcat('Image_', num2str(k), '.tif');
    
    %Read files
	imageData = imread(tifFileName);
    
    %Convert to Binary
    BW = imbinarize(imageData);
    
    %Crop out just the black background area
    cropped = imcrop(BW,[282.5 1.5 989 676]);
    
    %Write these to new file in Dir
    imwrite(cropped,strcat('Image_', num2str(k),'_cropped.tif')) ; 
    
    %Rename
    labeledImage = bwlabel(cropped);
    %imshow(labeledImage)
    
    %Color Blobs
    % Goal here is to assign a color to each blob
    coloredLabels = label2rgb(labeledImage, 'hsv', 'k', 'shuffle');
    %imshow(coloredLabels)
    
    %Find Centroids
    measurements = regionprops(labeledImage, 'centroid');
    centroids = cat(1, measurements.Centroid);
    
    %Determine XY coordinates of centroids
    %Not working?
    centroidX = centroids(1:2:end); % Extract x centroids.
    centroidY = centroids(2:2:end); % Extract y centroids.
    fprintf('Centroid X = ', centroidX, 'CentroidY = ', centroidY)

    % Show centroids of bubbles
    % Only working for one image?
    imshow(labeledImage)
    axis on
    hold on
    plot(imgca,centroids(:,1), centroids(:,2), 'b*')
    hold off
  
end


%Read files from the directory, make them binary, crop them, find centroid
clear 
for k = 1 : 50
	pause(.005)
    % Read through sequential images and show them.
	tifFileName = strcat('Image_', num2str(k), '_cropped.tif');
    
    %Read files
	imageData = imread(tifFileName);
    
    %Convert to Binary
    %BW = imbinarize(imageData);
    BW = imageData;
    
    %Crop out just the black background area
    %cropped = imcrop(BW,[282.5 1.5 989 676]);
    cropped = BW;
    
    %Write these to new file in Dir
    %imwrite(cropped,strcat('Image_', num2str(k),'_cropped.tif')) ; 
    
    %Rename
    labeledImage = bwlabel(cropped);
    %imshow(labeledImage)
    
%     % Bounding Box
%     info = regionprops(labeledImage,'Boundingbox') ;
%     imshow(labeledImage)
%     hold on
%     for k = 1 : length(info)
%         BB = info(k).BoundingBox;
%         rectangle('Position', [BB(1),BB(2),BB(3),BB(4)],'EdgeColor','r','LineWidth',2) ;
%     end
    
    
    %Color Blobs
    % Goal here is to assign a color to each blob
    %coloredLabels = label2rgb(labeledImage, 'hsv', 'k', 'shuffle');
    %imshow(coloredLabels)
%     
%     %Line Test
%     imshow(labeledImage);
%     hold on
%     line([0 760],[0 0],'linewidth',3);
%     % so are the lines 3 and 4........
%     fig=gcf;
%     imwrite(fig,strcat('Image_', num2str(k), '_cropped_line.tif'));
%     hold off

    %Find Centroids
    measurements = regionprops(labeledImage, 'centroid');
    centroids = cat(1, measurements.Centroid);
    
    %Determine XY coordinates of centroids
    %Not working?
    %centroidX = centroids(:,1); % Extract x centroids.
    %centroidY = centroids(:,2); % Extract y centroids.
    centroid(k).X = centroids(:,1); % Extract x centroids.
    centroid(k).Y = centroids(:,2); % Extract y centroids.
    
    %fprintf('Centroid X = ', centroidX, 'CentroidY = ', centroidY)

    % Show centroids of bubbles
    % Only working for one image?
% %     imshow(labeledImage)
% %     axis on
% %     hold on
% %     plot(centroid(k).X, centroid(k).Y, 'o')
% %     hold off
% %   
end

for k = 1:2
    j = k+1;
    index_matrix = [1:1:length(centroid(k).X)]';
    %m = 1; %starting bubble, in the k image 

    for m = 1:length(centroid(k).X)
        for ii = 1:length(centroid(j).X) %loop over possible bubbles, finding distance 
            Dist(ii) = sqrt( (centroid(k).X(m)-centroid(j).X(ii))^2 + (centroid(k).Y(m)-centroid(j).Y(ii))^2);
        end
        [dumb, ind] = min(Dist);
        index_matrix(m,j) = ind;
        %location = [centroid(k).X(index_matrix(j,k)),centroid(k).Y(index_matrix(j,k))]
        index_matrix
    end
end